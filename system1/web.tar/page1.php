<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    .center-frame {
      display: block;
      margin-left: auto;
      margin-right: auto;
    }
  </style>
</head>
<body>
  <iframe class="center-frame" src="index.php" width="362px" height="192px" style="border:0px"></iframe>
</body>
</html>
