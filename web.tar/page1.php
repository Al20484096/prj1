<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-header%407.2.9%3A%2Fdemos%2Fsrc%2Fmain.scss%2Co-colors%2Co-normalise">
  <title>Page 1</title>
</head>
<body>

  <header class="o-header o-header--simple" data-o-component="o-header" data-o-header--no-js="">
	<div class="o-header__row o-header__top">
		<div class="o-header__container">
			<div class="o-header__top-wrapper">

				<div class="o-header__top-column o-header__top-column--left">
					<a href="#o-header-drawer" class="o-header__top-link o-header__top-link--menu" aria-controls="o-header-drawer" title="Open drawer menu">
						<span class="o-header__top-link-label">Menu</span>
					</a>

				</div>

				<div class="o-header__top-column o-header__top-column--center">
					<!--<div class="o-header__top-takeover"></div>-->
					<a class="o-header__top-logo" href="index.php" title="Go to Financial Times homepage">
						<span class="o-header__visually-hidden">Financial Times</span>
					</a>
				</div>

				<div class="o-header__top-column o-header__top-column--right">
					<!--<div class="o-header__top-takeover"></div>-->
					<a class="o-header__top-link o-header__top-link--myft" href="#" aria-label="My F T">
						<span class="o-header__visually-hidden">myFT</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</header>

<div class="o-header__drawer" id="o-header-drawer" role="navigation" aria-label="Drawer menu" data-o-header-drawer="" data-o-header-drawer--no-js="">
	<div class="o-header__drawer-inner">

		<div class="o-header__drawer-tools">
			<a class="o-header__drawer-tools-logo" href="index.php">
				<span class="o-header__visually-hidden">Financial Times</span>
			</a>
			<button type="button" class="o-header__drawer-tools-close" aria-controls="o-header-drawer" title="Close drawer menu">
				<span class="o-header__visually-hidden">Close</span>
			</button>
		</div>

		<nav class="o-header__drawer-menu o-header__drawer-menu--primary">
			<ul class="o-header__drawer-menu-list">
						<li class="o-header__drawer-menu-item o-header__drawer-menu-item--heading">Main Menu</li>
						<li class="o-header__drawer-menu-item ">
								<a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="index.php" >Home</a>
						</li>

						<li class="o-header__drawer-menu-item ">
								<a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--selected" aria-label="Current page" aria-selected="true" href="page1.php">Page 1</a>
						</li>

            <li class="o-header__drawer-menu-item ">
                <a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="page2.php">Page 2</a>
            </li>

            <li class="o-header__drawer-menu-item ">
                <a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="page3.php">Page 3</a>
            </li>

			</ul>
		</nav>

    <nav class="o-header__drawer-menu o-header__drawer-menu--user">
      <ul class="o-header__drawer-menu-list">
            <li class="o-header__drawer-menu-item">
              <a class="o-header__drawer-menu-link" href="ratings.php">View Ratings</a>
            </li>
      </ul>
    </nav>

	</div>
</div>

<script src="//www.ft.com/__origami/service/build/v2/bundles/js?modules=o-header%407.2.9%3A%2Fdemos%2Fsrc%2Fmain.js%2Co-colors%2Co-normalise"></script>


  <center><h1>Page 1</h1></center>
  <iframe class="center-frame" src="rate1.php" width="362px" height="192px" style="border:0px"></iframe>
</body>
</html>
