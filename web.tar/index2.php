<!DOCTYPE html>
<html lang="en">
<head>

  <link rel="stylesheet" href="css/styles.css" />
	<script src="js/client.min.js"></script>
	<link rel="stylesheet" href="https://build.origami.ft.com/v2/bundles/css?modules=o-grid@^4.3.8" />
	<script src="https://build.origami.ft.com/v2/bundles/js?modules=o-grid@^4.3.8"></script>
	<!--<link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-grid%404.3.8%3A%2Fdemos%2Fsrc%2Fscss%2Fdefault.scss">-->
	<link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-header%407.2.9%3A%2Fdemos%2Fsrc%2Fmain.scss%2Co-colors%2Co-normalise">





</head>
<body onload="setUid()">

<script>
  var client = new ClientJS();
  var fingerprint = client.getFingerprint(); // Get Client's Fingerprint

      function setUid()
      {
        document.getElementById("uid").value = fingerprint;
      }
</script>


<?php
  if ( $_SERVER['HTTP_REFERER'] == "" ) {
    echo "Your rating system is not configured correctly";
  }
  else {
    if ( $_POST["calling_page"] != "" ) {
      $calling_page = $_POST["calling_page"];
    }
    else {
      $calling_page = $_SERVER['HTTP_REFERER'];
    }

    if ( $_POST["rating"] != "" && $_POST["uid"] != "" ) {

      $servername = "localhost";
      $username = "root";
      $password = "root";
      $dbname = "ratingdb";

      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error)
      {
        die("Connection failed: ".$conn->connect_error);
      }



        $sql = "INSERT INTO ratings (page, rating, uid, date) VALUES ( '".$calling_page."', '". $_POST['rating']. "', '".$_POST['uid']."', '" .date("Y-m-d"). "')";
        if ($conn->query($sql) === TRUE) {
          echo '
          <div id="rating_box">
            <div class="o-grid-container center">

              <div class="o-grid-row">
                <div data-o-grid-colspan="12"><div class="rating-cell title">Thank you for rating our page</div></div>
                <div data-o-grid-colspan="12"><img src="images/'.$_POST['rating'].'.png"></div>
              </div>
          ';

        }
        else {
          echo "System Malfunction";
        }

    }
    else {
      echo '
      <div id="rating_box">
        <div class="o-grid-container center">

          <div class="o-grid-row">
            <div data-o-grid-colspan="12"><div class="rating-cell title">Please rate our website</div></div>
          </div>

          <div class="o-grid-row">
            <form action="index2.php" method="post">
              <div data-o-grid-colspan="3"><button class="rating" name="rating" value="1" type="submit"><img src="images/1.png"></button></div>
              <div data-o-grid-colspan="3"><button class="rating" name="rating" value="2" type="submit"><img src="images/2.png"></button></div>
              <div data-o-grid-colspan="3"><button class="rating" name="rating" value="3" type="submit"><img src="images/3.png"></button></div>
              <div data-o-grid-colspan="3"><button class="rating" name="rating" value="4" type="submit"><img src="images/4.png"></button></div>
              <input type="hidden" id="uid" name="uid" value="">
              <input type="hidden" name="calling_page" value="'.$calling_page.'">
            </form>
          </div>

        </div>
      </div>
      ';
    }

  }
?>
</body>
</html>
