<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    .center-frame {
      display: block;
      margin-left: auto;
      margin-right: auto;
    }
  </style>
  <title>Page 3</title>
</head>
<body>
  <iframe class="center-frame" src="index2.php" width="362px" height="192px" style="border:0px"></iframe>
</body>
</html>
