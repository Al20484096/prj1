<!DOCTYPE html>
<html lang="en">
<head>

  <link rel="stylesheet" href="css/styles.css" />
	<script src="js/client.min.js"></script>
	<link rel="stylesheet" href="https://build.origami.ft.com/v2/bundles/css?modules=o-grid@^4.3.8" />
	<script src="https://build.origami.ft.com/v2/bundles/js?modules=o-grid@^4.3.8"></script>
	<!--<link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-grid%404.3.8%3A%2Fdemos%2Fsrc%2Fscss%2Fdefault.scss">-->
	<link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-header%407.2.9%3A%2Fdemos%2Fsrc%2Fmain.scss%2Co-colors%2Co-normalise">





</head>
<body>

<?php



$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "ratingdb";



$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error)
{
  die("Connection failed: ".$conn->connect_error);
}

if ( $_POST["id"] != "" ) {
    $sql1 = "DELETE FROM ratings WHERE id='".$_POST["id"]."'";
      if ($conn->query($sql1) === TRUE) {
      }
      else {
        echo "Database connection error";
      }

}

$sql1 = "SELECT * FROM ratings";
$result = $conn->query($sql1);
if ( $result->num_rows > 0) {
  echo "<form action='ratings.php' method='post'>";
  echo "<table align='center'>";
  echo "<tr><td></td><td width=50px><b>ID</b></td><td width=300px><b>Page</b></td><td width=100px><b>Ratings</b></td><td width=100px><b>User ID</b></td><td><b>Date</b></td></tr>";
  while($row = $result->fetch_assoc()) {
    echo "<tr><td><button type='submit' name='id' value='".$row["id"]."'>Delete</button></td><td>".$row["id"]."</td><td>".$row["page"]."</td><td>".$row["rating"]."</td><td>".$row["uid"]."</td><td>".$row["date"]."</td></tr>";
  }
  echo "</table>";
  echo "</form>";
}

?>

</body>
</html>
