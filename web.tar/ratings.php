<!DOCTYPE html>
<html lang="en">
<head>

  <link rel="stylesheet" href="css/styles.css" />
	<script src="js/client.min.js"></script>
	<link rel="stylesheet" href="https://build.origami.ft.com/v2/bundles/css?modules=o-grid@^4.3.8" />
	<script src="https://build.origami.ft.com/v2/bundles/js?modules=o-grid@^4.3.8"></script>
	<!--<link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-grid%404.3.8%3A%2Fdemos%2Fsrc%2Fscss%2Fdefault.scss">-->
	<link rel="stylesheet" href="//www.ft.com/__origami/service/build/v2/bundles/css?modules=o-header%407.2.9%3A%2Fdemos%2Fsrc%2Fmain.scss%2Co-colors%2Co-normalise">

  <title>Ratings</title>
</head>
<body>

  <header class="o-header o-header--simple" data-o-component="o-header" data-o-header--no-js="">
	<div class="o-header__row o-header__top">
		<div class="o-header__container">
			<div class="o-header__top-wrapper">

				<div class="o-header__top-column o-header__top-column--left">
					<a href="#o-header-drawer" class="o-header__top-link o-header__top-link--menu" aria-controls="o-header-drawer" title="Open drawer menu">
						<span class="o-header__top-link-label">Menu</span>
					</a>

				</div>

				<div class="o-header__top-column o-header__top-column--center">
					<!--<div class="o-header__top-takeover"></div>-->
					<a class="o-header__top-logo" href="index.php" title="Go to Financial Times homepage">
						<span class="o-header__visually-hidden">Financial Times</span>
					</a>
				</div>

				<div class="o-header__top-column o-header__top-column--right">
					<!--<div class="o-header__top-takeover"></div>-->
					<a class="o-header__top-link o-header__top-link--myft" href="#" aria-label="My F T">
						<span class="o-header__visually-hidden">myFT</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</header>

<div class="o-header__drawer" id="o-header-drawer" role="navigation" aria-label="Drawer menu" data-o-header-drawer="" data-o-header-drawer--no-js="">
	<div class="o-header__drawer-inner">

		<div class="o-header__drawer-tools">
			<a class="o-header__drawer-tools-logo" href="index.php">
				<span class="o-header__visually-hidden">Financial Times</span>
			</a>
			<button type="button" class="o-header__drawer-tools-close" aria-controls="o-header-drawer" title="Close drawer menu">
				<span class="o-header__visually-hidden">Close</span>
			</button>
		</div>

		<nav class="o-header__drawer-menu o-header__drawer-menu--primary">
			<ul class="o-header__drawer-menu-list">
						<li class="o-header__drawer-menu-item o-header__drawer-menu-item--heading">Main Menu</li>
						<li class="o-header__drawer-menu-item ">
								<a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="index.php" >Home</a>
						</li>

						<li class="o-header__drawer-menu-item ">
								<a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="page1.php">Page 1</a>
						</li>

            <li class="o-header__drawer-menu-item ">
                <a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="page2.php">Page 2</a>
            </li>

            <li class="o-header__drawer-menu-item ">
                <a class="o-header__drawer-menu-link o-header__drawer-menu-link-- o-header__drawer-menu-link--unselected" href="page3.php">Page 3</a>
            </li>

			</ul>
		</nav>

    <nav class="o-header__drawer-menu o-header__drawer-menu--user">
      <ul class="o-header__drawer-menu-list">
            <li class="o-header__drawer-menu-item">
              <a class="o-header__drawer-menu-link" href="ratings.php">View Ratings</a>
            </li>
      </ul>
    </nav>

	</div>
</div>

<script src="//www.ft.com/__origami/service/build/v2/bundles/js?modules=o-header%407.2.9%3A%2Fdemos%2Fsrc%2Fmain.js%2Co-colors%2Co-normalise"></script>


<center><h1>Ratings</h1></center>
<?php



$servername = "ratingdb.caypmgaujypn.us-east-2.rds.amazonaws.com";
$username = "awsuser_db";
$password = "awsdbpassword";
$dbname = "ratingdb";



$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error)
{
  die("Connection failed: ".$conn->connect_error);
}

if ( $_POST["id"] != "" ) {
  if ( $_POST["id"] == "*" ) {
    $sql1 = "DELETE FROM ratings";
      if ($conn->query($sql1) === TRUE) {
      }
      else {
        echo "Database connection error";
      }

  } else {



    $sql1 = "DELETE FROM ratings WHERE id='".$_POST["id"]."'";
      if ($conn->query($sql1) === TRUE) {
      }
      else {
        echo "Database connection error";
      }
  }
}

$sql1 = "SELECT * FROM ratings";
$result = $conn->query($sql1);
if ( $result->num_rows > 0) {
  echo "<form action='ratings.php' method='post'>";
  echo "<table align='center'>";
  echo "<tr><td><button type='submit' name='id' value='*'>Del. All</button></td><td width=50px><b>ID</b></td><td width=300px><b>Page</b></td><td width=100px><b>Ratings</b></td><td width=100px><b>User ID</b></td><td><b>Date</b></td></tr>";
  while($row = $result->fetch_assoc()) {
    echo "<tr><td><button type='submit' name='id' value='".$row["id"]."'>Delete</button></td><td>".$row["id"]."</td><td>".$row["page"]."</td><td>".$row["rating"]."</td><td>".$row["uid"]."</td><td>".$row["date"]."</td></tr>";
  }
  echo "</table>";
  echo "</form>";



}

?>

</body>
</html>
